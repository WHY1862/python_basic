#' Gapminder data, unfiltered.
#'
#' The supplemental data frame `gapminder_unfiltered` was not filtered on
#' `year` or for complete data and has 3313 rows. Everything else is as
#' documented in [`gapminder`].
"gapminder_unfiltered"
